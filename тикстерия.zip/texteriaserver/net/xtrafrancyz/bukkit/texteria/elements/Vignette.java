package net.xtrafrancyz.bukkit.texteria.elements;

import net.xtrafrancyz.bukkit.texteria.elements.Element;

public class Vignette extends Element<Vignette> {
   public Vignette(String id) {
      super(id);
   }

   protected String getType() {
      return "Vignette";
   }
}
