package net.xtrafrancyz.mods.texteria.util;

public enum Position
{
    TOP_RIGHT,
    TOP,
    TOP_LEFT,
    BOTTOM_RIGHT,
    BOTTOM,
    BOTTOM_LEFT,
    RIGHT,
    LEFT,
    CENTER;
}
