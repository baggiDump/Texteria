package net.xtrafrancyz.mods.texteria.elements;

import net.xtrafrancyz.util.ByteMap;

public class Spacer extends Rectangle
{
    public Spacer(ByteMap params)
    {
        super(params);
    }

    public void renderInContainer(long time)
    {
    }

    public void render(long time)
    {
    }
}
