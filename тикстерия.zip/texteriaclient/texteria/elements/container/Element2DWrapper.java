package net.xtrafrancyz.mods.texteria.elements.container;

import net.xtrafrancyz.mods.texteria.elements.Element2D;

public interface Element2DWrapper
{
    Element2D getElement2D();
}
